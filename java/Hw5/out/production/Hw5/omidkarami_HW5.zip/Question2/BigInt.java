package Question2;

import java.util.Arrays;


public class BigInt {
    public static void main(String[] args) {
        BigInt big = new BigInt(1377);
        BigInt bi = new BigInt("34444");
        bi.sum(big);
    }

    String stringNumber;

    public BigInt(int intNumber) {
        intConvertToString(intNumber);
        print(stringNumber);
    }//End of BigInt(int intNumber)

    public BigInt(String stringNumber) {
        this.stringNumber = stringNumber;
        print(stringNumber);
    }//End of BigInt(String stringNumber)

    public void intConvertToString(int intNumber) {
        this.stringNumber = String.valueOf(intNumber);
    }//End of intConvertToString(int intNumber)

    //Casting char types to int types
    public int charConvertToInt(char ch) {
        switch (ch) {
            case '0':
                return 0;
            case '1':
                return 1;
            case '2':
                return 2;
            case '3':
                return 3;
            case '4':
                return 4;
            case '5':
                return 5;
            case '6':
                return 6;
            case '7':
                return 7;
            case '8':
                return 8;
            case '9':
                return 9;
        }//End of switch(ch)
        return 0;
    }//End of charConvertToInt(char ch)

    //Casting array[int] types to String types
    public void arrayIntConvertToString(int[] number) {
        String ultimateNumber = "";
        for (int i = 0; i < number.length; i++) {
            ultimateNumber += number[i];
        }//End of for(int i=0 ; i<number.length ; i++)
        print(ultimateNumber);
    }//End of arrayIntConvertToString(int[] number)

    public void sum(BigInt bigIntParameter) {
        int middleCounter = 0;
        if (this.stringNumber.length() > bigIntParameter.getStringNumber().length()) {
            String middleString = this.stringNumber;
            this.stringNumber = bigIntParameter.getStringNumber();
            bigIntParameter.setStringNumber(middleString);
        }//End of if(this.stringNumber.length() > bigIntParameter.getStringNumber().length())

        int[] sum = new int[bigIntParameter.getStringNumber().length()];
//for(int i=0 ; i<sum.length ; i++){
//System.out.println("sum[" + i + "]= " + sum[i]);
//}//End of for(int i=0 ; i<sum.length ; i++)
        int middleSum = 0;

        for (int i = bigIntParameter.getStringNumber().length() - 1, j = this.stringNumber.length() - 1; i >= 0 && j >= 0; i--, j--) {
            middleSum = charConvertToInt(stringNumber.charAt(j)) + charConvertToInt(bigIntParameter.getStringNumber().charAt(i)) + sum[i];
            sum[i] = 0;
            if (middleSum >= 10) {
//System.out.println("middleSum = " + middleSum);
                sum[i - 1] += middleSum / 10;
//System.out.println("sum[i-1] = " + sum[i-1]);
                sum[i] += middleSum % 10;
//System.out.println("sum[i] = " + sum[i]);
            }//End of (middleSum>=10)
            else {
                sum[i] += middleSum;
//System.out.println("middleSum = " + middleSum);
//System.out.println("sum[i] = " + sum[i]);
            }//End of else
//System.out.println(charConvertToInt(stringNumber.charAt(j)) + "+" + charConvertToInt(bigIntParameter.getStringNumber().charAt(i)) + "=" + sum[i]);
            middleCounter = i;
        }//End of for(int i=bigIntParameter.getStringNumber().length()-1 , j=this.stringNumber.length()-1 ; i>=0 && j>=0 ; i-- , j--)

        middleCounter--;
        while (middleCounter >= 0) {
            middleSum = charConvertToInt(bigIntParameter.getStringNumber().charAt(middleCounter)) + sum[middleCounter];
            sum[middleCounter] = 0;
            if (middleSum >= 10) {
//System.out.println("middleSum = " + middleSum);
                sum[middleCounter - 1] += middleSum / 10;
//System.out.println("sum[middleCounter-1] = " + sum[middleCounter-1]);
                sum[middleCounter] += middleSum % 10;
//System.out.println("sum[middleCounter] = " + sum[middleCounter]);
            }//End of (middleSum>=10)
            else {
                sum[middleCounter] += middleSum;
//System.out.println("middleSum = " + middleSum);
//System.out.println("sum[middleCounter] = " + sum[middleCounter]);
            }//End of else
            middleCounter--;
        }//End of while(middleCounter>=0)

        arrayIntConvertToString(sum);

    }//End of sum(BigInt1 bigIntParameter)

    public void print(String stringNumber) {
        System.out.println(stringNumber);
    }//End of print(String stringNumber)

    public String getStringNumber() {
        return stringNumber;
    }//End of getStringNumber()

    public void setStringNumber(String stringNumber) {
        this.stringNumber = stringNumber;
    }//End of setStringNumber(String stringNumber)
}//End of class BigInt