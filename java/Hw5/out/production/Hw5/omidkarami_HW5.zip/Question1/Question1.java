package Question1;

import java.util.Arrays;

public class Question1 {
    public static void main(String[] args) {
        Container a = new Container(10);
        a.add(3);
        a.add(5);
        a.add(10);
        a.add(8);
        a.sortBtp();
        a.sortPtB();
        a.deleteByIndex(0);
        a.deleteByValue(10);
        System.out.println(a.find(7));
        System.out.println(a.find(5));
    }
}

class Container{

    private int[] numbers;
    private int tedad;
    public Container(int n) {
        numbers = new int[n];
        tedad = 0;
    }

    public void sortPtB()
    {

        for (int i = 0; i < tedad; i++) {
            for (int j = i + 1; j < tedad; j++) {
                if(numbers[i] > numbers[j]){
                    int temp = numbers[i];
                    numbers[i] = numbers[j];
                    numbers[j] = temp;
                }
            }
        }
    }

    public void sortBtp(){
        this.sortPtB();
        int[] a =new int[numbers.length];
        for (int i = 0; i < tedad; i++) {
            a[tedad - i - 1] = numbers[i];
        }
        numbers = a;
    }

    public void add(int n){
        numbers[tedad] = n;
        tedad++;
    }

    public void deleteByIndex(int i){
        for (int j = i; j < tedad - 1; j++) {
            numbers[j] = numbers[j + 1];
        }
            tedad--;
    }

    public void deleteByValue(int i){
        for (int j = 0; j < tedad; j++) {
            if(numbers[j] == i)
                deleteByIndex(j);
        }
    }

    public int find(int i){
        for (int j = 0; j < tedad; j++) {
            if(i == numbers[j])
                return j;
        }
        return -1;
    }
}
