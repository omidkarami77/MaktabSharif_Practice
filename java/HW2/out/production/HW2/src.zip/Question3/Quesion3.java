package Question3;

public class Quesion3 {
    public static void main(String[] args) {
        A[] elements = {new D(), new A(), new C(), new B()};
        for (int i = 0; i < elements.length; i++) {
            System.out.println(elements[i].method1());
            System.out.println(elements[i].method2());
            System.out.println();
        }
    }
}

class A {
    public String method1() {
        return "A1";
    }

    public String method2() {
        return "A2";
    }
}

class B extends A {
    @Override
    public String method1() {
        return super.method1();
    }

    @Override
    public String method2() {
        return method1() + "B2";
    }
}

class C extends A {
    @Override
    public String method1() {
        return "C1";
    }

    @Override
    public String method2() {
        return method1() + "B2";
    }
}

class D extends A {
    @Override
    public String method1() {
        return "D1";
    }

    @Override
    public String method2() {
        return method1() +  "B2";
    }
}